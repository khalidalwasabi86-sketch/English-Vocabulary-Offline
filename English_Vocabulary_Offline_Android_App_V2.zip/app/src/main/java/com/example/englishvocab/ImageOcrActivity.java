package com.example.englishvocab;

import android.app.*; import android.os.*; import android.net.Uri; import android.graphics.Bitmap;
import android.provider.MediaStore; import android.view.*; import android.widget.*;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.TextRecognition; import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;
import java.util.*; import java.util.regex.*;

public class ImageOcrActivity extends Activity {
    LinearLayout list; TextView status; ArrayList<String> uriStrings=new ArrayList<>();
    TextRecognizer recognizer;
    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(14,14,14,14);
        status=new TextView(this); status.setText("🔍 جارٍ استخراج الكلمات من الصور..."); root.addView(status);
        ScrollView sc=new ScrollView(this); list=new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL); sc.addView(list);
        root.addView(sc,new LinearLayout.LayoutParams(-1,0,1)); setContentView(root);
        recognizer=TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
        ArrayList<String> passed=bundleUris(getIntent());
        for(String s:passed) process(Uri.parse(s));
    }
    ArrayList<String> bundleUris(Intent i){
        ArrayList<String> a=i.getStringArrayListExtra("uris");
        if(a!=null)return a;
        String one=i.getStringExtra("uri"); if(one!=null)a=new ArrayList<>(); else a=new ArrayList<>();
        if(one!=null)a.add(one); return a;
    }
    void process(Uri u){
        try{
            InputImage img=InputImage.fromFilePath(this,u);
            recognizer.process(img).addOnSuccessListener(result->{
                String text=result.getText();
                ArrayList<String> words=extractEnglishWords(text);
                for(String w:words) addWord(w);
                status.setText("تم استخراج الكلمات. اضغط 🔊 لسماع النطق، ويمكنك لاحقًا تعديل الكلمة أو معناها.");
            }).addOnFailureListener(e->status.setText("تعذر تحليل صورة: "+e.getMessage()));
        }catch(Exception e){status.setText("تعذر فتح الصورة: "+e.getMessage());}
    }
    ArrayList<String> extractEnglishWords(String text){
        LinkedHashSet<String> set=new LinkedHashSet<>();
        Matcher m=Pattern.compile("\\b[A-Za-z][A-Za-z' -]{1,40}\\b").matcher(text);
        while(m.find()){
            String s=m.group().trim().replaceAll("\\s+"," ");
            if(s.length()>=2 && !s.matches(".*\\d.*")) set.add(s);
        }
        return new ArrayList<>(set);
    }
    void addWord(String word){
        LinearLayout row=new LinearLayout(this); row.setOrientation(LinearLayout.VERTICAL); row.setPadding(8,12,8,12);
        TextView t=new TextView(this); t.setText("🇬🇧 "+word); t.setTextSize(19); row.addView(t);
        Button speak=new Button(this); speak.setText("🔊 نطق الكلمة"); row.addView(speak);
        speak.setOnClickListener(v->TtsHelper.speak(this,word));
        list.addView(row);
    }
    @Override protected void onDestroy(){if(recognizer!=null)recognizer.close();super.onDestroy();}
}
