package com.example.englishvocab;

import android.app.*; import android.os.*; import android.view.*; import android.widget.*; import java.util.*;

public class VocabularyActivity extends Activity {
    LinearLayout list; EditText search;
    String[] words={"burglar alarm","backache","call","get","should","can"};
    String[] ar={"إنذار ضد السرقة","ألم الظهر","يتصل / ينادي","يحصل / يصبح / يأخذ (بحسب السياق)","ينبغي / يجب","يستطيع / يمكنه"};
    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(14,14,14,14);
        TextView title=new TextView(this); title.setText("📖 المفردات"); title.setTextSize(24); title.setTypeface(null,1); root.addView(title);
        search=new EditText(this); search.setHint("🔎 ابحث..."); root.addView(search);
        ScrollView sc=new ScrollView(this); list=new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL); sc.addView(list);
        root.addView(sc,new LinearLayout.LayoutParams(-1,0,1)); setContentView(root);
        fill("");
        search.addTextChangedListener(new android.text.TextWatcher(){
            public void beforeTextChanged(CharSequence s,int a,int c,int d){}
            public void onTextChanged(CharSequence s,int a,int b,int c){fill(s.toString().toLowerCase());}
            public void afterTextChanged(android.text.Editable e){}
        });
    }
    void fill(String q){
        list.removeAllViews();
        for(int i=0;i<words.length;i++){
            if(!words[i].toLowerCase().contains(q)&&!ar[i].contains(q))continue;
            LinearLayout row=new LinearLayout(this); row.setOrientation(LinearLayout.VERTICAL); row.setPadding(8,12,8,12);
            TextView t=new TextView(this); t.setText("🇬🇧 "+words[i]+"\n🇦🇪 "+ar[i]); t.setTextSize(17); row.addView(t);
            Button speak=new Button(this); speak.setText("🔊 نطق"); row.addView(speak);
            speak.setOnClickListener(v->TtsHelper.speak(this,words[i]));
            list.addView(row);
        }
    }
}
