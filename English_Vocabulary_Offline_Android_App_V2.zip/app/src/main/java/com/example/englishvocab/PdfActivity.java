package com.example.englishvocab;

import android.app.*; import android.os.*; import android.net.Uri;
import android.graphics.*; import android.graphics.pdf.PdfRenderer; import android.os.ParcelFileDescriptor;
import android.view.*; import android.widget.*;

public class PdfActivity extends Activity {
    PdfRenderer renderer; ParcelFileDescriptor pfd; ImageView image; TextView pageText; int pageIndex=0;
    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        LinearLayout bar=new LinearLayout(this);
        Button prev=new Button(this); prev.setText("◀ السابق");
        Button next=new Button(this); next.setText("التالي ▶");
        pageText=new TextView(this); pageText.setGravity(Gravity.CENTER);
        bar.addView(prev,new LinearLayout.LayoutParams(0,-2,1));
        bar.addView(pageText,new LinearLayout.LayoutParams(0,-2,1));
        bar.addView(next,new LinearLayout.LayoutParams(0,-2,1));
        root.addView(bar);
        ScrollView sc=new ScrollView(this); image=new ImageView(this);
        image.setAdjustViewBounds(true); image.setScaleType(ImageView.ScaleType.FIT_CENTER); sc.addView(image);
        root.addView(sc,new LinearLayout.LayoutParams(-1,0,1)); setContentView(root);
        try { pfd=getContentResolver().openFileDescriptor(getIntent().getData(),"r"); renderer=new PdfRenderer(pfd); render(); }
        catch(Exception e){ Toast.makeText(this,"تعذر فتح PDF: "+e.getMessage(),Toast.LENGTH_LONG).show(); finish(); }
        prev.setOnClickListener(v->{if(pageIndex>0){pageIndex--;render();}});
        next.setOnClickListener(v->{if(renderer!=null&&pageIndex<renderer.getPageCount()-1){pageIndex++;render();}});
    }
    void render(){
        PdfRenderer.Page p=renderer.openPage(pageIndex);
        int w=Math.min(p.getWidth()*2,1800), h=(int)((float)w/p.getWidth()*p.getHeight());
        Bitmap bm=Bitmap.createBitmap(w,h,Bitmap.Config.ARGB_8888); bm.eraseColor(Color.WHITE);
        p.render(bm,null,null,PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY); p.close();
        image.setImageBitmap(bm); pageText.setText((pageIndex+1)+" / "+renderer.getPageCount());
    }
    @Override protected void onDestroy(){try{if(renderer!=null)renderer.close();}catch(Exception ignored){} try{if(pfd!=null)pfd.close();}catch(Exception ignored){} super.onDestroy();}
}
