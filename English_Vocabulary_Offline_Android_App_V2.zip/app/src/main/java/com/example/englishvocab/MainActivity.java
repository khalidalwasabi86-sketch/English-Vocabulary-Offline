package com.example.englishvocab;

import android.app.*;
import android.os.*;
import android.content.*;
import android.net.Uri;
import android.provider.Settings;
import android.view.*;
import android.widget.*;
import java.io.*;
import java.util.*;

public class MainActivity extends Activity {
    static final int PDF_REQ=100, IMG_REQ=101, AUDIO_REQ=102;
    TextView status;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);
        status=findViewById(R.id.status);

        findViewById(R.id.addPdf).setOnClickListener(v -> choosePdf());
        findViewById(R.id.addImages).setOnClickListener(v -> chooseImages());
        findViewById(R.id.addAudio).setOnClickListener(v -> chooseAudio());
        findViewById(R.id.openVocab).setOnClickListener(v ->
            startActivity(new Intent(this, VocabularyActivity.class)));
    }

    void choosePdf() {
        Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.setType("application/pdf"); i.addCategory(Intent.CATEGORY_OPENABLE);
        startActivityForResult(i, PDF_REQ);
    }

    void chooseImages() {
        Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.setType("image/*"); i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        startActivityForResult(i, IMG_REQ);
    }

    void chooseAudio() {
        Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.setType("audio/*"); i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        startActivityForResult(i, AUDIO_REQ);
    }

    @Override protected void onActivityResult(int req,int result,Intent data) {
        super.onActivityResult(req,result,data);
        if(result!=RESULT_OK || data==null) return;

        if(req==PDF_REQ) {
            Uri u=data.getData();
            try { getContentResolver().takePersistableUriPermission(u,Intent.FLAG_GRANT_READ_URI_PERMISSION); } catch(Exception ignored){}
            Intent x=new Intent(this,PdfActivity.class); x.setData(u); startActivity(x);
        } else if(req==IMG_REQ) {
            Intent x=new Intent(this,ImageOcrActivity.class);
            if(data.getClipData()!=null) {
                ArrayList<String> uris=new ArrayList<>();
                for(int i=0;i<data.getClipData().getItemCount();i++)
                    uris.add(data.getClipData().getItemAt(i).getUri().toString());
                x.putStringArrayListExtra("uris",uris);
            } else if(data.getData()!=null) {
                x.putExtra("uri",data.getData().toString());
            }
            startActivity(x);
        } else if(req==AUDIO_REQ) {
            int count=0;
            if(data.getClipData()!=null) count=data.getClipData().getItemCount();
            else if(data.getData()!=null) count=1;
            status.setText("تم اختيار "+count+" ملف صوت. سيُحفظ داخل التطبيق عند ربطه بالكلمات.");
            Toast.makeText(this,"تم اختيار ملفات الصوت",Toast.LENGTH_SHORT).show();
        }
    }
}
