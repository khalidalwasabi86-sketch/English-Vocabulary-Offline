package com.example.englishvocab;

import android.content.Context; import android.speech.tts.TextToSpeech; import java.util.*;

public class TtsHelper {
    static TextToSpeech tts;
    static void speak(Context c,String text){
        if(tts==null){
            tts=new TextToSpeech(c.getApplicationContext(),status->{
                if(status==TextToSpeech.SUCCESS){
                    int r=tts.setLanguage(Locale.US);
                    tts.setSpeechRate(0.92f);
                    tts.speak(text,TextToSpeech.QUEUE_FLUSH,null,"vocab");
                }
            });
        } else {
            tts.setLanguage(Locale.US); tts.setSpeechRate(0.92f);
            tts.speak(text,TextToSpeech.QUEUE_FLUSH,null,"vocab");
        }
    }
}
